// PeerPlay relay + rendezvous server. Run on any machine with a reachable TCP port:
//
//     java RelayServer.java [port]        (default 25580, needs JDK 21+)
//
// It does three things: remembers which hosts are online, tells peers each other's NAT-mapped endpoint
// (for hole punching), and forwards bytes when direct and punched routes fail. It cannot read friend
// identities or authenticate anyone; PeerPlay's own signed handshake runs end to end through it.
// Note that game traffic crossing the relay is not encrypted by Minecraft in offline mode.

import java.io.*;
import java.net.*;
import java.security.SecureRandom;
import java.util.HexFormat;
import java.util.Map;
import java.util.concurrent.*;
import java.util.regex.Pattern;

public class RelayServer {
	record Host(Socket sock, DataOutputStream out, String observed) { }

	static final class Session {
		final CompletableFuture<Socket> host = new CompletableFuture<>();
	}

	static final Map<String, Host> hosts = new ConcurrentHashMap<>();
	static final Map<String, Session> sessions = new ConcurrentHashMap<>();
	static final Pattern ID = Pattern.compile("[0-9a-f]{32}");
	static final int MAX_HOSTS = 5000;
	static final SecureRandom RNG = new SecureRandom();

	public static void main(String[] args) throws Exception {
		int port = args.length > 0 ? Integer.parseInt(args[0]) : 25580;
		ServerSocket ss = new ServerSocket(port);
		System.out.println("PeerPlay relay listening on " + port);
		while (true) {
			Socket s = ss.accept();
			Thread.ofVirtual().start(() -> handle(s));
		}
	}

	static String obs(Socket s) {
		return ((InetSocketAddress) s.getRemoteSocketAddress()).getAddress().getHostAddress() + ":" + s.getPort();
	}

	static void handle(Socket s) {
		boolean keep = false;
		try {
			s.setTcpNoDelay(true);   // low latency for game packets
			s.setKeepAlive(true);    // keeps mobile NAT mappings and dead peers honest
			s.setSoTimeout(10_000);
			DataInputStream in = new DataInputStream(s.getInputStream());
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			String cmd = in.readUTF();
			switch (cmd) {
				case "HOST" -> keep = host(s, in, out);
				case "JOIN" -> keep = join(s, in, out);
				case "ACCEPT" -> keep = accept(s, in);
				default -> { }
			}
		} catch (Exception ignored) {
		} finally {
			if (!keep) close(s);
		}
	}

	static boolean host(Socket s, DataInputStream in, DataOutputStream out) throws Exception {
		String id = in.readUTF();
		if (!ID.matcher(id).matches() || hosts.size() >= MAX_HOSTS) return false;
		Host h = new Host(s, out, obs(s));
		Host old = hosts.put(id, h);
		if (old != null) close(old.sock());
		synchronized (out) { out.writeUTF("OK"); out.writeUTF(h.observed()); out.flush(); }
		s.setSoTimeout(0);
		try {
			while (!s.isClosed()) {
				Thread.sleep(15_000);  // under typical mobile-NAT idle timeouts
				synchronized (out) { out.writeUTF("PING"); out.flush(); }
			}
		} catch (Exception ignored) {
		} finally {
			hosts.remove(id, h);
		}
		return false;
	}

	static boolean join(Socket s, DataInputStream in, DataOutputStream out) throws Exception {
		String id = in.readUTF();
		Host h = ID.matcher(id).matches() ? hosts.get(id) : null;
		if (h == null) { out.writeUTF("NOHOST"); out.flush(); return false; }
		String sid = HexFormat.of().formatHex(RNG.generateSeed(12));
		Session sess = new Session();
		sessions.put(sid, sess);
		boolean piped = false;
		try {
			synchronized (h.out()) {
				h.out().writeUTF("INCOMING"); h.out().writeUTF(sid); h.out().writeUTF(obs(s)); h.out().flush();
			}
			out.writeUTF("SESSION"); out.writeUTF(sid); out.writeUTF(h.observed()); out.flush();
			s.setSoTimeout(15_000);
			String next = in.readUTF();
			if (next.equals("RELAY")) {
				Socket hs = sess.host.get(10, TimeUnit.SECONDS);
				DataOutputStream hout = new DataOutputStream(hs.getOutputStream());
				hout.writeUTF("READY"); hout.flush();
				out.writeUTF("READY"); out.flush();
				bridge(s, hs);
				piped = true;
			}
		} finally {
			sessions.remove(sid);
			if (!piped && sess.host.isDone() && !sess.host.isCompletedExceptionally()) close(sess.host.getNow(null));
		}
		return piped;
	}

	static boolean accept(Socket s, DataInputStream in) throws Exception {
		String sid = in.readUTF();
		Session sess = sessions.get(sid);
		if (sess == null) return false;
		s.setSoTimeout(0);
		return sess.host.complete(s); // the JOIN handler now owns this socket
	}

	static void bridge(Socket a, Socket b) throws IOException {
		a.setSoTimeout(0); b.setSoTimeout(0);
		Runnable done = () -> { close(a); close(b); };
		pump(a, b, done);
		pump(b, a, done);
	}

	static void pump(Socket from, Socket to, Runnable done) {
		Thread.ofVirtual().start(() -> {
			try { from.getInputStream().transferTo(to.getOutputStream()); } catch (IOException ignored) { } finally { done.run(); }
		});
	}

	static void close(Socket s) {
		if (s == null) return;
		try { s.close(); } catch (IOException ignored) { }
	}
}
