# PeerPlay (Fabric, Minecraft Java 26.2)

Play with friends directly, with no Mojang session server in the loop, and a friends list to join whoever is hosting.
Works behind most home networks with no setup, and behind any network if someone runs a relay.

## Build
JDK 25: `gradle build` -> `build/libs/peerplay-1.0.0.jar`. Needs Fabric Loader 0.19.5+ and Fabric API 0.159.0+26.2.

## Use
1. Title screen / pause menu -> **Friends (P2P)** (or `/friends`).
2. Optional: type a **relay** (`host:port`) and press Apply. Your direct address is auto-filled when UPnP/STUN can find it.
3. **Copy my code**, swap codes with a friend, each **Add friend** (both directions needed).
4. Open a world -> Friends -> **Broadcast world**. Friends press **Refresh**, then **Join**.

## Network settings (Friends -> Network settings)
One toggle per route (UPnP, Direct, Hole punching, Relay) and a **Cellular / hotspot mode** preset that turns off
UPnP, direct and hole punching, keeps the relay on, and caps the host's view distance at 6 chunks (data saver; the host
view-distance button cycles off/4/6/8). In cellular mode joins go straight to the relay (about 15 ms of setup instead of
a multi-second probe), friend codes carry only your relay, and nothing probes the router or STUN servers.
The relay link reconnects with growing delays (1s up to 30s) so a tower change or hotspot sleep heals itself.
A game already in progress cannot survive a dropped connection; rejoin after it recovers.

## How a join connects (tried in order)
1. **Direct**: your friend's address. UPnP opens the port on your router automatically on most home routers.
2. **Hole punching**: both sides connect to each other at once, coordinated by the relay (best effort).
3. **Relay**: the relay forwards bytes. Always works when both can reach the relay.
The status line at the bottom shows UPnP state and relay state; the join entry shows which route was used.

## Running a relay
Any machine with a reachable TCP port (a cheap VPS, or a PC with a forwarded port):
`java relay/RelayServer.java 25580`  (JDK 21+). Put `thatmachine:25580` in the Relay box. Friends only need their own
relay entry if they also want to be reachable that way; a friend's code carries their relay address.

## Security
- Ed25519 identity per install; both sides sign a challenge, so the relay and network cannot impersonate anyone.
- Only friends get presence or a game connection. The game port is never shown or forwarded; peers connect through the gate.
- The relay sees (and could tamper with) game traffic: offline-mode Minecraft is not encrypted. Run your own relay for friends you trust.

## Tests
`tests/run.sh /path/to/gson.jar` runs 31 protocol/relay/gate tests on loopback. UPnP, STUN and real-NAT hole punching
need a real network and are only covered by parser tests here.
