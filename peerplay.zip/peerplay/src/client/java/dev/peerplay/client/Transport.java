package dev.peerplay.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.StandardSocketOptions;

/**
 * Opens a byte stream to a friend's PeerPlay gate using the routes enabled in Network settings:
 *   1. direct TCP to the friend's address (UPnP, port forwarding, VPN, LAN, public IPv6)
 *   2. TCP hole punching, coordinated by the relay (game joins only)
 *   3. the relay forwarding bytes (works whenever both sides can reach the relay)
 * In cellular mode steps 1 and 2 are off, so a join goes straight to the relay with no probing delay.
 */
public final class Transport {
	private final FriendStore store;
	public volatile String lastRoute = "";

	public Transport(FriendStore store) {
		this.store = store;
	}

	/** A socket that can later be re-bound by hole punching (same local port). */
	public static Socket reuseSocket() throws IOException {
		Socket s = new Socket();
		s.setReuseAddress(true);
		try { s.setOption(StandardSocketOptions.SO_REUSEPORT, true); } catch (UnsupportedOperationException | IOException ignored) { }
		s.bind(new InetSocketAddress(0));
		return s;
	}

	public static InetSocketAddress endpoint(String hostPort) {
		int i = hostPort.lastIndexOf(':');
		if (i < 0) throw new IllegalArgumentException("expected host:port, got " + hostPort);
		return InetSocketAddress.createUnresolved(hostPort.substring(0, i), Integer.parseInt(hostPort.substring(i + 1)));
	}

	private static InetSocketAddress resolved(String hostPort) {
		InetSocketAddress u = endpoint(hostPort);
		return new InetSocketAddress(u.getHostString(), u.getPort());
	}

	public Socket open(FriendStore.Friend f, boolean allowPunch) throws IOException {
		FriendStore.Settings cfg = store.settings;
		IOException last = null;
		if (cfg.useDirect && f.host != null && !f.host.isBlank()) {
			try {
				Socket s = new Socket();
				s.setTcpNoDelay(true);
				s.connect(new InetSocketAddress(f.host, f.presencePort), 2500);
				lastRoute = "direct";
				return s;
			} catch (IOException e) {
				last = e;
			}
		}
		if (cfg.useRelay && f.relay != null && !f.relay.isBlank()) {
			return viaRelay(f, allowPunch && cfg.usePunch);
		}
		if (last != null) throw last;
		throw new IOException("no usable route to " + f.name + " (check Network settings)");
	}

	private Socket viaRelay(FriendStore.Friend f, boolean punchFirst) throws IOException {
		Socket c = reuseSocket();
		boolean handedOff = false;
		try {
			c.setTcpNoDelay(true);
			c.setKeepAlive(true);
			c.connect(resolved(f.relay), 6000);
			c.setSoTimeout(10_000);
			DataOutputStream out = new DataOutputStream(c.getOutputStream());
			DataInputStream in = new DataInputStream(c.getInputStream());
			out.writeUTF("JOIN");
			out.writeUTF(FriendStore.hostId(f.pubKey));
			out.flush();
			String r = in.readUTF();
			if (r.equals("NOHOST")) throw new IOException(f.name + " is not connected to the relay");
			if (!r.equals("SESSION")) throw new IOException("bad relay reply");
			in.readUTF(); // session id (host side uses it)
			String hostObserved = in.readUTF();

			if (punchFirst) {
				Socket p = punch(c.getLocalPort(), hostObserved, 4500);
				if (p != null) {
					out.writeUTF("DONE");
					out.flush();
					Pipe.close(c);
					lastRoute = "hole-punch";
					handedOff = true;
					return p;
				}
			}
			out.writeUTF("RELAY");
			out.flush();
			if (!in.readUTF().equals("READY")) throw new IOException("relay could not reach host");
			c.setSoTimeout(0);
			lastRoute = "relay";
			handedOff = true;
			return c;
		} finally {
			if (!handedOff) Pipe.close(c);
		}
	}

	/**
	 * TCP simultaneous open: both peers connect to each other's NAT-mapped endpoint from the same local
	 * port they used toward the relay, so each NAT sees an outbound packet first. Best effort; fails on
	 * symmetric NATs and CGNAT, in which case the caller falls back to the relay.
	 */
	public static Socket punch(int localPort, String peerHostPort, int timeoutMs) {
		long end = System.currentTimeMillis() + timeoutMs;
		InetSocketAddress peer;
		try { peer = resolved(peerHostPort); } catch (Exception e) { return null; }
		while (System.currentTimeMillis() < end) {
			Socket s = null;
			try {
				s = new Socket();
				s.setReuseAddress(true);
				try { s.setOption(StandardSocketOptions.SO_REUSEPORT, true); } catch (UnsupportedOperationException | IOException ignored) { }
				s.bind(new InetSocketAddress(localPort));
				s.connect(peer, 1200);
				return s;
			} catch (IOException e) {
				if (s != null) Pipe.close(s);
				try { Thread.sleep(150); } catch (InterruptedException ie) { return null; }
			}
		}
		return null;
	}
}
