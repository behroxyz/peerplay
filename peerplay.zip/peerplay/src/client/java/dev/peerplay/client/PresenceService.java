package dev.peerplay.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * The PeerPlay gate: one listener that serves two requests over any transport (direct, punched or relayed).
 *
 * "PP1" presence:  requester proves its key (signed timestamp); host answers live/not, signed.
 * "PG1" game join: host proves its key (signed nonce); requester proves its key bound to that nonce and to
 *                  the host's key; only then does the host connect the stream to the local game server.
 *
 * Only friends get an answer, and the game port is never revealed or exposed to peers.
 */
public final class PresenceService {
	public record Status(boolean reachable, boolean live, String name, String motd, String error) {
		static Status fail(String why) { return new Status(false, false, "", "", why); }
	}

	private final Identity identity;
	private final FriendStore store;
	private final Transport transport;
	private volatile boolean running;
	private ServerSocket server;

	private volatile boolean live;
	private volatile int gamePort;
	private volatile String motd = "";
	private volatile String myName = "Player";

	public PresenceService(Identity identity, FriendStore store, Transport transport) {
		this.identity = identity;
		this.store = store;
		this.transport = transport;
	}

	public void setBroadcast(boolean live, int gamePort, String motd, String myName) {
		this.live = live;
		this.gamePort = gamePort;
		this.motd = motd;
		this.myName = myName;
	}

	public boolean isLive() { return live; }

	public void start() {
		if (running) return;
		running = true;
		Thread t = new Thread(() -> {
			try {
				server = new ServerSocket();
				server.setReuseAddress(true);
				server.bind(new InetSocketAddress(store.settings.presencePort));
				while (running) {
					Socket s = server.accept();
					Thread h = new Thread(() -> handle(s), "PeerPlay-gate-conn");
					h.setDaemon(true);
					h.start();
				}
			} catch (Exception e) {
				if (running) System.err.println("[PeerPlay] Gate listener stopped: " + e);
			}
		}, "PeerPlay-gate");
		t.setDaemon(true);
		t.start();
	}

	public void stop() {
		running = false;
		try { if (server != null) server.close(); } catch (Exception ignored) { }
	}

	private static String nonce() {
		byte[] b = new byte[16];
		new SecureRandom().nextBytes(b);
		return Base64.getEncoder().encodeToString(b);
	}

	/** Serves one inbound connection from any transport. Takes ownership of the socket. */
	public void handle(Socket s) {
		boolean piped = false;
		try {
			s.setSoTimeout(5000);
			DataInputStream in = new DataInputStream(s.getInputStream());
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			String cmd = in.readUTF();
			if ("PP1".equals(cmd)) {
				handlePresence(in, out);
			} else if ("PG1".equals(cmd)) {
				piped = handleGame(s, in, out);
			}
		} catch (Exception ignored) {
		} finally {
			if (!piped) Pipe.close(s);
		}
	}

	private void handlePresence(DataInputStream in, DataOutputStream out) throws Exception {
		String reqKey = in.readUTF();
		long time = in.readLong();
		String sig = in.readUTF();
		boolean fresh = Math.abs(System.currentTimeMillis() - time) < 60_000;
		if (!fresh || store.byKey(reqKey) == null || !Identity.verify(reqKey, "req|" + time, sig)) {
			out.writeBoolean(false);
			out.flush();
			return;
		}
		boolean l = live;
		String name = myName;
		out.writeBoolean(true);
		out.writeBoolean(l);
		out.writeUTF(name);
		out.writeUTF(motd);
		out.writeUTF(identity.publicKey());
		out.writeUTF(identity.sign("resp|" + time + "|" + l + "|" + name));
		out.flush();
	}

	/** @return true if the socket was handed to a pipe (caller must not close it). */
	private boolean handleGame(Socket s, DataInputStream in, DataOutputStream out) throws Exception {
		String n = nonce();
		out.writeUTF(identity.publicKey());
		out.writeUTF(n);
		out.writeUTF(identity.sign("hostchal|" + n));
		out.flush();
		String reqKey = in.readUTF();
		String sig = in.readUTF();
		boolean ok = store.byKey(reqKey) != null
				&& Identity.verify(reqKey, "game|" + n + "|" + identity.publicKey(), sig);
		int port = gamePort;
		if (!ok || !live || port <= 0) {
			out.writeBoolean(false);
			out.flush();
			return false;
		}
		Socket game;
		try {
			game = new Socket("127.0.0.1", port);
		} catch (Exception e) {
			out.writeBoolean(false);
			out.flush();
			return false;
		}
		out.writeBoolean(true);
		out.flush();
		Pipe.bridge(s, game);
		return true;
	}

	/** Blocking; call from a background thread. */
	public Status query(FriendStore.Friend f) {
		try (Socket s = transport.open(f, false)) {
			s.setSoTimeout(5000);
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			DataInputStream in = new DataInputStream(s.getInputStream());
			long time = System.currentTimeMillis();
			out.writeUTF("PP1");
			out.writeUTF(identity.publicKey());
			out.writeLong(time);
			out.writeUTF(identity.sign("req|" + time));
			out.flush();
			if (!in.readBoolean()) return Status.fail("Friend has not added you back");
			boolean l = in.readBoolean();
			String name = in.readUTF();
			String motd = in.readUTF();
			String hostKey = in.readUTF();
			String sig = in.readUTF();
			if (!hostKey.equals(f.pubKey) || !Identity.verify(hostKey, "resp|" + time + "|" + l + "|" + name, sig)) {
				return Status.fail("Identity mismatch");
			}
			return new Status(true, l, name, motd, null);
		} catch (Exception e) {
			return Status.fail("Offline");
		}
	}
}
