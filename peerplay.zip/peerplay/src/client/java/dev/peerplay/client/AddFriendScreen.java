package dev.peerplay.client;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class AddFriendScreen extends Screen {
	private final Screen parent;
	private EditBox codeBox;
	private Component msg = Component.empty();

	public AddFriendScreen(Screen parent) {
		super(Component.literal("Add friend"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int cx = width / 2;
		int y = height / 2 - 40;
		addRenderableWidget(new StringWidget(cx - 150, y, 300, 12, Component.literal("Paste your friend's code (pp2:...)"), font));
		codeBox = new EditBox(font, cx - 150, y + 18, 300, 20, Component.literal("Friend code"));
		codeBox.setMaxLength(1024);
		addRenderableWidget(codeBox);
		setInitialFocus(codeBox);
		addRenderableWidget(Button.builder(Component.literal("Add"), b -> add())
				.bounds(cx - 100, y + 46, 95, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose())
				.bounds(cx + 5, y + 46, 95, 20).build());
		addRenderableWidget(new StringWidget(cx - 150, y + 74, 300, 12, msg, font));
	}

	private void add() {
		FriendStore.Friend f = FriendStore.parseCode(codeBox.getValue());
		if (f == null) {
			msg = Component.literal("That is not a valid friend code.");
			rebuildWidgets();
			return;
		}
		if (f.pubKey.equals(PeerPlayClient.identity.publicKey())) {
			msg = Component.literal("That is your own code.");
			rebuildWidgets();
			return;
		}
		PeerPlayClient.store.add(f);
		onClose();
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}
}
