package dev.peerplay.client;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.security.SecureRandom;

/** Minimal STUN (RFC 5389) binding request: learns your public IP as the internet sees it. */
public final class Stun {
	private Stun() { }

	private static final String[][] SERVERS = {{"stun.l.google.com", "19302"}, {"stun.cloudflare.com", "3478"}};

	/** @return public IPv4 string, or null if no STUN server answered. */
	public static String publicIp() {
		for (String[] sv : SERVERS) {
			try (DatagramSocket s = new DatagramSocket()) {
				s.setSoTimeout(2000);
				byte[] req = new byte[20];
				req[1] = 0x01; // Binding Request
				req[4] = 0x21; req[5] = 0x12; req[6] = (byte) 0xA4; req[7] = 0x42; // magic cookie
				byte[] tx = new byte[12];
				new SecureRandom().nextBytes(tx);
				System.arraycopy(tx, 0, req, 8, 12);
				s.send(new DatagramPacket(req, req.length, new InetSocketAddress(InetAddress.getByName(sv[0]), Integer.parseInt(sv[1]))));
				byte[] buf = new byte[512];
				DatagramPacket p = new DatagramPacket(buf, buf.length);
				s.receive(p);
				String ip = parse(buf, p.getLength(), req);
				if (ip != null) return ip;
			} catch (Exception ignored) {
			}
		}
		return null;
	}

	/** Parses a Binding Success Response; returns the (XOR-)mapped IPv4 address or null. */
	public static String parse(byte[] r, int len, byte[] req) {
		if (len < 20 || r[0] != 0x01 || r[1] != 0x01) return null;
		for (int i = 0; i < 12; i++) if (r[8 + i] != req[8 + i]) return null;
		int i = 20;
		while (i + 4 <= len) {
			int type = ((r[i] & 0xff) << 8) | (r[i + 1] & 0xff);
			int alen = ((r[i + 2] & 0xff) << 8) | (r[i + 3] & 0xff);
			int v = i + 4;
			if (v + alen > len) return null;
			if ((type == 0x0020 || type == 0x0001) && alen >= 8 && r[v + 1] == 0x01) {
				byte[] ip = new byte[4];
				for (int k = 0; k < 4; k++) {
					ip[k] = r[v + 4 + k];
					if (type == 0x0020) ip[k] ^= req[4 + k];
				}
				return (ip[0] & 0xff) + "." + (ip[1] & 0xff) + "." + (ip[2] & 0xff) + "." + (ip[3] & 0xff);
			}
			i = v + ((alen + 3) & ~3);
		}
		return null;
	}

	/** True for private, loopback, link-local and carrier-grade-NAT (100.64/10) addresses. */
	public static boolean isPrivate(String ip) {
		try {
			String[] p = ip.split("\\.");
			int a = Integer.parseInt(p[0]), b = Integer.parseInt(p[1]);
			return a == 10 || a == 127 || (a == 172 && b >= 16 && b <= 31) || (a == 192 && b == 168)
					|| (a == 169 && b == 254) || (a == 100 && b >= 64 && b <= 127);
		} catch (Exception e) {
			return true;
		}
	}
}
