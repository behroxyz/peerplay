package dev.peerplay.client;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * Local Ed25519 identity. This replaces account-server authentication for peers:
 * a friend is trusted because they hold the private key matching the public key
 * you added, not because a central service vouched for a username.
 */
public final class Identity {
	private static final Gson GSON = new Gson();
	private final PrivateKey priv;
	private final PublicKey pub;

	private Identity(PrivateKey priv, PublicKey pub) {
		this.priv = priv;
		this.pub = pub;
	}

	public static Path dir() {
		Path d = FabricLoader.getInstance().getConfigDir().resolve("peerplay");
		try { Files.createDirectories(d); } catch (Exception ignored) { }
		return d;
	}

	public static Identity loadOrCreate() throws Exception {
		Path file = dir().resolve("identity.json");
		KeyFactory kf = KeyFactory.getInstance("Ed25519");
		if (Files.exists(file)) {
			JsonObject o = GSON.fromJson(Files.readString(file), JsonObject.class);
			PrivateKey pr = kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(o.get("priv").getAsString())));
			PublicKey pu = kf.generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(o.get("pub").getAsString())));
			return new Identity(pr, pu);
		}
		KeyPair kp = KeyPairGenerator.getInstance("Ed25519").generateKeyPair();
		JsonObject o = new JsonObject();
		o.addProperty("priv", Base64.getEncoder().encodeToString(kp.getPrivate().getEncoded()));
		o.addProperty("pub", Base64.getEncoder().encodeToString(kp.getPublic().getEncoded()));
		Files.writeString(file, GSON.toJson(o));
		return new Identity(kp.getPrivate(), kp.getPublic());
	}

	public String publicKey() {
		return Base64.getEncoder().encodeToString(pub.getEncoded());
	}

	public String sign(String message) throws GeneralSecurityException {
		Signature s = Signature.getInstance("Ed25519");
		s.initSign(priv);
		s.update(message.getBytes(StandardCharsets.UTF_8));
		return Base64.getEncoder().encodeToString(s.sign());
	}

	public static boolean verify(String pubKeyB64, String message, String sigB64) {
		try {
			PublicKey pk = KeyFactory.getInstance("Ed25519")
					.generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(pubKeyB64)));
			Signature s = Signature.getInstance("Ed25519");
			s.initVerify(pk);
			s.update(message.getBytes(StandardCharsets.UTF_8));
			return s.verify(Base64.getDecoder().decode(sigB64));
		} catch (Exception e) {
			return false;
		}
	}
}
