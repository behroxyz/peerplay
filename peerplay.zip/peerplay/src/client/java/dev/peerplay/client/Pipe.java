package dev.peerplay.client;

import java.io.IOException;
import java.net.Socket;

/** Two-way byte bridge between sockets. Closing either side closes both. */
public final class Pipe {
	private Pipe() { }

	public static void bridge(Socket a, Socket b) {
		try { a.setSoTimeout(0); b.setSoTimeout(0); a.setTcpNoDelay(true); b.setTcpNoDelay(true); } catch (IOException ignored) { }
		Runnable closeBoth = () -> { close(a); close(b); };
		start(a, b, closeBoth);
		start(b, a, closeBoth);
	}

	private static void start(Socket from, Socket to, Runnable done) {
		Thread t = new Thread(() -> {
			try {
				from.getInputStream().transferTo(to.getOutputStream());
			} catch (IOException ignored) {
			} finally {
				done.run();
			}
		}, "PeerPlay-pipe");
		t.setDaemon(true);
		t.start();
	}

	public static void close(Socket s) {
		try { s.close(); } catch (IOException ignored) { }
	}
}
