package dev.peerplay.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/** Joiner side of a game session, plus the loopback proxy Minecraft actually connects to. */
public final class GameLink {
	private GameLink() { }

	/** Authenticated stream to the friend's game server, or an IOException explaining why not. */
	public static Socket open(Transport transport, Identity id, FriendStore.Friend f) throws IOException {
		Socket s = transport.open(f, true);
		boolean ok = false;
		try {
			s.setSoTimeout(8000);
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			DataInputStream in = new DataInputStream(s.getInputStream());
			out.writeUTF("PG1");
			out.flush();
			String hostKey = in.readUTF();
			String nonce = in.readUTF();
			String sig = in.readUTF();
			if (!hostKey.equals(f.pubKey) || !Identity.verify(hostKey, "hostchal|" + nonce, sig)) {
				throw new IOException("identity mismatch: this is not " + f.name);
			}
			try {
				out.writeUTF(id.publicKey());
				out.writeUTF(id.sign("game|" + nonce + "|" + hostKey));
			} catch (java.security.GeneralSecurityException e) {
				throw new IOException(e);
			}
			out.flush();
			if (!in.readBoolean()) throw new IOException(f.name + " refused (not friends, or not hosting)");
			s.setSoTimeout(0);
			ok = true;
			return s;
		} finally {
			if (!ok) Pipe.close(s);
		}
	}

	/** Listens once on 127.0.0.1 and bridges the first connection (Minecraft) to the remote stream. */
	public static int startLocalProxy(Socket remote) throws IOException {
		ServerSocket ss = new ServerSocket(0, 1, InetAddress.getLoopbackAddress());
		int port = ss.getLocalPort();
		Thread t = new Thread(() -> {
			try {
				ss.setSoTimeout(30_000);
				Socket mc = ss.accept();
				ss.close();
				Pipe.bridge(mc, remote);
			} catch (IOException e) {
				Pipe.close(remote);
				try { ss.close(); } catch (IOException ignored) { }
			}
		}, "PeerPlay-localproxy");
		t.setDaemon(true);
		t.start();
		return port;
	}
}
