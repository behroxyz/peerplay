package dev.peerplay.client;

import java.io.OutputStream;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** UPnP-IGD port mapping with no dependencies: SSDP discovery + SOAP over HTTP. */
public final class Upnp {
	private Upnp() { }

	public record Result(boolean ok, String externalIp, String error) { }
	public record Service(String type, String controlUrl) { }

	private static volatile String mappedControl;
	private static volatile String mappedType;
	private static volatile int mappedPort;

	public static Result map(int port, String description) {
		try {
			String location = discover();
			if (location == null) return new Result(false, null, "no UPnP gateway answered");
			URL base = new URL(location);
			String xml = http(base, null, null);
			Service svc = pickService(parseServices(xml));
			if (svc == null) return new Result(false, null, "gateway has no WAN connection service");
			URL control = new URL(base, svc.controlUrl());

			String localIp;
			try (DatagramSocket probe = new DatagramSocket()) {
				probe.connect(InetAddress.getByName(base.getHost()), 9);
				localIp = probe.getLocalAddress().getHostAddress();
			}
			String body = "<NewRemoteHost></NewRemoteHost><NewExternalPort>" + port + "</NewExternalPort>"
					+ "<NewProtocol>TCP</NewProtocol><NewInternalPort>" + port + "</NewInternalPort>"
					+ "<NewInternalClient>" + localIp + "</NewInternalClient><NewEnabled>1</NewEnabled>"
					+ "<NewPortMappingDescription>" + description + "</NewPortMappingDescription>"
					+ "<NewLeaseDuration>0</NewLeaseDuration>";
			soap(control, svc.type(), "AddPortMapping", body);
			String ipResp = soap(control, svc.type(), "GetExternalIPAddress", "");
			Matcher m = Pattern.compile("<NewExternalIPAddress>([^<]*)</NewExternalIPAddress>").matcher(ipResp);
			String ext = m.find() ? m.group(1).trim() : null;
			mappedControl = control.toString();
			mappedType = svc.type();
			mappedPort = port;
			return new Result(true, ext, null);
		} catch (Exception e) {
			return new Result(false, null, String.valueOf(e.getMessage()));
		}
	}

	public static void unmap() {
		if (mappedControl == null) return;
		try {
			soap(new URL(mappedControl), mappedType, "DeletePortMapping",
					"<NewRemoteHost></NewRemoteHost><NewExternalPort>" + mappedPort + "</NewExternalPort><NewProtocol>TCP</NewProtocol>");
		} catch (Exception ignored) {
		}
		mappedControl = null;
	}

	private static String discover() throws Exception {
		String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\n"
				+ "ST: urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\n\r\n";
		byte[] data = msg.getBytes(StandardCharsets.US_ASCII);
		try (DatagramSocket s = new DatagramSocket()) {
			s.setSoTimeout(1500);
			InetSocketAddress group = new InetSocketAddress(InetAddress.getByName("239.255.255.250"), 1900);
			for (int i = 0; i < 2; i++) s.send(new DatagramPacket(data, data.length, group));
			long end = System.currentTimeMillis() + 3500;
			byte[] buf = new byte[2048];
			while (System.currentTimeMillis() < end) {
				try {
					DatagramPacket p = new DatagramPacket(buf, buf.length);
					s.receive(p);
					String loc = parseLocation(new String(p.getData(), 0, p.getLength(), StandardCharsets.US_ASCII));
					if (loc != null) return loc;
				} catch (SocketTimeoutException e) {
					break;
				}
			}
		}
		return null;
	}

	public static String parseLocation(String response) {
		Matcher m = Pattern.compile("(?im)^location:\\s*(\\S+)").matcher(response);
		return m.find() ? m.group(1) : null;
	}

	public static List<Service> parseServices(String xml) {
		List<Service> out = new ArrayList<>();
		Matcher blocks = Pattern.compile("<service>(.*?)</service>", Pattern.DOTALL).matcher(xml);
		while (blocks.find()) {
			String b = blocks.group(1);
			Matcher t = Pattern.compile("<serviceType>([^<]*)</serviceType>").matcher(b);
			Matcher c = Pattern.compile("<controlURL>([^<]*)</controlURL>").matcher(b);
			if (t.find() && c.find()) out.add(new Service(t.group(1).trim(), c.group(1).trim()));
		}
		return out;
	}

	public static Service pickService(List<Service> all) {
		Service ppp = null;
		for (Service s : all) {
			if (s.type().contains("WANIPConnection")) return s;
			if (s.type().contains("WANPPPConnection")) ppp = s;
		}
		return ppp;
	}

	private static String soap(URL url, String type, String action, String args) throws Exception {
		String env = "<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
				+ "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:" + action + " xmlns:u=\"" + type + "\">"
				+ args + "</u:" + action + "></s:Body></s:Envelope>";
		return http(url, "\"" + type + "#" + action + "\"", env);
	}

	private static String http(URL url, String soapAction, String body) throws Exception {
		HttpURLConnection c = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
		c.setConnectTimeout(3000);
		c.setReadTimeout(4000);
		if (body != null) {
			c.setRequestMethod("POST");
			c.setDoOutput(true);
			c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
			c.setRequestProperty("SOAPAction", soapAction);
			try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
		}
		int code = c.getResponseCode();
		if (code >= 400) throw new Exception("HTTP " + code);
		return new String(c.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
	}
}
