package dev.peerplay.client;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Network settings: one toggle per route plus the cellular/hotspot preset. Widget-only, like the other screens. */
public final class SettingsScreen extends Screen {
	private static final int[] VIEW_DISTANCES = {0, 4, 6, 8};
	private final Screen parent;
	private Component hint = Component.empty();

	public SettingsScreen(Screen parent) {
		super(Component.literal("PeerPlay Network"));
		this.parent = parent;
	}

	private static String onOff(boolean b) { return b ? "ON" : "OFF"; }

	@Override
	protected void init() {
		FriendStore.Settings s = PeerPlayClient.store.settings;
		int cx = width / 2;
		int y = 12;
		addRenderableWidget(new StringWidget(cx - 150, y, 300, 12, title, font));
		y += 20;

		addRenderableWidget(Button.builder(Component.literal("Cellular / hotspot mode: " + onOff(s.cellularMode)), b -> {
			s.applyCellular(!s.cellularMode);
			if (s.cellularMode) Upnp.unmap();
			changed();
			PeerPlayClient.detectNetwork();
			hint = Component.literal(s.cellularMode
					? "Relay-first: no probing, no UPnP, smaller host view distance."
					: "Back to automatic: direct, UPnP, hole punching, then relay.");
			rebuildWidgets();
		}).bounds(cx - 150, y, 300, 20).build());
		y += 28;

		toggle(cx, y, "UPnP (open router port)", s.upnp, v -> s.upnp = v, () -> {
			if (!s.upnp) Upnp.unmap();
			PeerPlayClient.detectNetwork();
		});
		y += 24;
		toggle(cx, y, "Direct connection", s.useDirect, v -> s.useDirect = v, null);
		y += 24;
		toggle(cx, y, "Hole punching", s.usePunch, v -> s.usePunch = v, null);
		y += 24;
		toggle(cx, y, "Relay", s.useRelay, v -> s.useRelay = v, () -> PeerPlayClient.relayHost.reconfigure());
		y += 24;

		String vd = s.hostViewDistance == 0 ? "off" : s.hostViewDistance + " chunks";
		addRenderableWidget(Button.builder(Component.literal("Host data saver (view distance): " + vd), b -> {
			int i = 0;
			for (int k = 0; k < VIEW_DISTANCES.length; k++) if (VIEW_DISTANCES[k] == s.hostViewDistance) i = k;
			s.hostViewDistance = VIEW_DISTANCES[(i + 1) % VIEW_DISTANCES.length];
			changed();
			hint = Component.literal("Applies the next time you broadcast a world.");
			rebuildWidgets();
		}).bounds(cx - 150, y, 300, 20).build());
		y += 28;

		addRenderableWidget(new StringWidget(cx - 150, y, 300, 12, hint, font));
		addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
				.bounds(cx - 50, height - 26, 100, 20).build());
	}

	private void toggle(int cx, int y, String label, boolean value, java.util.function.Consumer<Boolean> set, Runnable after) {
		addRenderableWidget(Button.builder(Component.literal(label + ": " + onOff(value)), b -> {
			set.accept(!value);
			// Editing a route by hand means you are no longer on the plain preset.
			PeerPlayClient.store.settings.cellularMode = PeerPlayClient.store.settings.cellularMode
					&& !PeerPlayClient.store.settings.useDirect && !PeerPlayClient.store.settings.usePunch;
			changed();
			if (after != null) after.run();
			rebuildWidgets();
		}).bounds(cx - 150, y, 300, 20).build());
	}

	private void changed() {
		PeerPlayClient.store.save();
		PeerPlayClient.relayHost.reconfigure();
	}

	@Override
	public void onClose() {
		PeerPlayClient.store.save();
		minecraft.setScreen(parent);
	}
}
