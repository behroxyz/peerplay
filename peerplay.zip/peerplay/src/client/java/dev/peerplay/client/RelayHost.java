package dev.peerplay.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * Keeps your install registered with the relay so friends can reach you from behind any NAT.
 * For each incoming session it (a) tries hole punching toward the joiner (if enabled) and (b) offers a
 * relayed connection; the joiner picks whichever works. Everything lands in PresenceService.handle(),
 * so the friend check and signed handshake apply to every route.
 *
 * Built for flaky links: if the connection drops (phone changes tower, hotspot sleeps) it reconnects
 * quickly with a growing delay instead of hammering the relay.
 */
public final class RelayHost {
	private final Identity identity;
	private final FriendStore store;
	private final PresenceService gate;
	private volatile boolean running;
	private volatile Socket control;
	private Thread thread;
	public volatile String state = "relay: off";

	public RelayHost(Identity identity, FriendStore store, PresenceService gate) {
		this.identity = identity;
		this.store = store;
		this.gate = gate;
	}

	public synchronized void reconfigure() {
		stop();
		String relay = store.settings.relay;
		if (!store.settings.useRelay || relay == null || relay.isBlank()) {
			state = "relay: off";
			return;
		}
		running = true;
		thread = new Thread(() -> loop(relay.trim()), "PeerPlay-relay-host");
		thread.setDaemon(true);
		thread.start();
	}

	public synchronized void stop() {
		running = false;
		Socket c = control;
		if (c != null) Pipe.close(c);
		if (thread != null) thread.interrupt();
		thread = null;
	}

	private void loop(String relay) {
		String hostId = FriendStore.hostId(identity.publicKey());
		long backoff = 1000;
		while (running) {
			try {
				state = "relay: connecting...";
				Socket c = Transport.reuseSocket();
				control = c;
				InetSocketAddress ep = Transport.endpoint(relay);
				c.setTcpNoDelay(true);
				c.setKeepAlive(true);
				c.connect(new InetSocketAddress(ep.getHostString(), ep.getPort()), 8000);
				c.setSoTimeout(60_000); // server pings every 20s
				DataOutputStream out = new DataOutputStream(c.getOutputStream());
				DataInputStream in = new DataInputStream(c.getInputStream());
				out.writeUTF("HOST");
				out.writeUTF(hostId);
				out.flush();
				if (!in.readUTF().equals("OK")) throw new java.io.IOException("relay refused");
				in.readUTF(); // our observed endpoint
				state = "relay: connected";
				backoff = 1000;
				int localPort = c.getLocalPort();
				while (running) {
					String cmd = in.readUTF();
					if (cmd.equals("INCOMING")) {
						String sid = in.readUTF();
						String joinerObserved = in.readUTF();
						session(relay, sid, joinerObserved, localPort);
					}
				}
			} catch (Exception e) {
				if (running) state = "relay: reconnecting";
			}
			if (running) {
				try { Thread.sleep(backoff); } catch (InterruptedException ie) { return; }
				backoff = Math.min(backoff * 2, 30_000);
			}
		}
	}

	private void session(String relay, String sid, String joinerObserved, int localPort) {
		if (store.settings.usePunch) {
			Thread punch = new Thread(() -> {
				Socket p = Transport.punch(localPort, joinerObserved, 4500);
				if (p != null) gate.handle(p);
			}, "PeerPlay-punch");
			punch.setDaemon(true);
			punch.start();
		}

		Thread accept = new Thread(() -> {
			Socket a = null;
			try {
				a = new Socket();
				a.setTcpNoDelay(true);
				a.setKeepAlive(true);
				InetSocketAddress ep = Transport.endpoint(relay);
				a.connect(new InetSocketAddress(ep.getHostString(), ep.getPort()), 8000);
				a.setSoTimeout(20_000);
				DataOutputStream out = new DataOutputStream(a.getOutputStream());
				DataInputStream in = new DataInputStream(a.getInputStream());
				out.writeUTF("ACCEPT");
				out.writeUTF(sid);
				out.flush();
				if (in.readUTF().equals("READY")) {
					gate.handle(a);
					return;
				}
			} catch (Exception ignored) {
			}
			if (a != null) Pipe.close(a);
		}, "PeerPlay-relay-accept");
		accept.setDaemon(true);
		accept.start();
	}
}
