package dev.peerplay.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.GameType;

public final class PeerPlayClient implements ClientModInitializer {
	public static Identity identity;
	public static FriendStore store;
	public static Transport transport;
	public static PresenceService presence;
	public static RelayHost relayHost;

	/** Shown at the bottom of the friends screen. */
	public static volatile String upnpStatus = "UPnP: checking...";
	public static volatile String detectedIp = "";

	@Override
	public void onInitializeClient() {
		try {
			identity = Identity.loadOrCreate();
		} catch (Exception e) {
			throw new RuntimeException("PeerPlay: could not create identity", e);
		}
		store = new FriendStore();
		transport = new Transport(store);
		presence = new PresenceService(identity, store, transport);
		relayHost = new RelayHost(identity, store, presence);
		presence.start();
		relayHost.reconfigure();
		detectNetwork();

		ClientLifecycleEvents.CLIENT_STOPPING.register(c -> {
			presence.stop();
			relayHost.stop();
			Upnp.unmap();
		});

		// "Friends" button on the title and pause screens.
		ScreenEvents.AFTER_INIT.register((mc, screen, w, h) -> {
			if (screen instanceof TitleScreen || screen instanceof PauseScreen) {
				Screens.getButtons(screen).add(Button.builder(Component.literal("Friends (P2P)"),
						b -> mc.setScreen(new FriendsScreen(screen)))
						.bounds(6, 6, 100, 20).build());
			}
		});

		// Fallback: /friends opens the screen in-game.
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, ctx) ->
				dispatcher.register(ClientCommands.literal("friends").executes(c -> {
					Minecraft mc = Minecraft.getInstance();
					mc.execute(() -> mc.setScreen(new FriendsScreen(null)));
					return 1;
				})));
	}

	/** Route 1 helpers: ask the router for a port (UPnP) and learn the public IP (STUN). Runs in the background. */
	public static void detectNetwork() {
		if (store.settings.cellularMode) {
			// Phone data sits behind carrier NAT: probing would only waste time and data.
			upnpStatus = "Cellular mode: relay-first";
			detectedIp = "";
			return;
		}
		Thread t = new Thread(() -> {
			String stunIp = Stun.publicIp();
			if (store.settings.upnp) {
				Upnp.Result r = Upnp.map(store.settings.presencePort, "PeerPlay");
				if (r.ok()) {
					boolean cgnat = r.externalIp() == null || Stun.isPrivate(r.externalIp())
							|| (stunIp != null && !stunIp.equals(r.externalIp()));
					upnpStatus = cgnat ? "UPnP: opened, but your ISP shares your IP (use a relay)"
							: "UPnP: port " + store.settings.presencePort + " open";
					detectedIp = cgnat ? "" : r.externalIp();
				} else {
					upnpStatus = "UPnP: unavailable (" + r.error() + ")";
				}
			} else {
				upnpStatus = "UPnP: off";
			}
			if (detectedIp.isEmpty() && stunIp != null && !upnpStatus.contains("use a relay")) detectedIp = stunIp;
		}, "PeerPlay-netdetect");
		t.setDaemon(true);
		t.start();
	}

	/**
	 * Opens the current singleplayer world to peers. The game server stays bound to localhost-style use:
	 * peers never learn its port, they come through the PeerPlay gate. Returns the game port, or -1.
	 */
	public static int startBroadcast(Minecraft mc) {
		IntegratedServer server = mc.getSingleplayerServer();
		if (server == null) return -1;
		try {
			if (!server.isPublished()) {
				int port = net.minecraft.util.HttpUtil.getAvailablePort();
				if (!server.publishServer(GameType.SURVIVAL, false, port)) return -1;
			}
			// Offline mode: joiners are not checked against Mojang's session servers. Who may join is
			// decided by the PeerPlay gate (signed friend handshake) instead.
			server.setUsesAuthentication(false);
			int port = server.getPort();
			int vd = store.settings.hostViewDistance;
			if (vd > 0) {
				// Data saver: fewer chunks streamed per player.
				try { server.getPlayerList().setViewDistance(vd); } catch (Throwable t) { System.err.println("[PeerPlay] view distance: " + t); }
			}
			presence.setBroadcast(true, port, server.getMotd(), mc.getUser().getName());
			return port;
		} catch (Throwable t) {
			System.err.println("[PeerPlay] Broadcast failed: " + t);
			return -1;
		}
	}

	public static void stopBroadcast() {
		presence.setBroadcast(false, 0, "", "");
	}
}
