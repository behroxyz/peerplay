package dev.peerplay.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HexFormat;
import java.util.List;

/** Friends + settings, persisted as JSON next to the identity. */
public final class FriendStore {
	public static final class Friend {
		public String name;
		/** Direct address (may be empty if the friend only uses the relay). */
		public String host = "";
		public int presencePort = 25570;
		public String pubKey;
		/** The friend's relay, host:port (may be empty). */
		public String relay = "";
	}

	public static final class Settings {
		/** Address friends use to reach you directly (public IP, DDNS name, VPN address). Optional. */
		public String publicHost = "";
		public int presencePort = 25570;
		/** Relay host:port you register on. Optional but makes joining work behind any NAT. */
		public String relay = "";
		// Route switches (each has a toggle in Network settings).
		public boolean upnp = true;
		public boolean useDirect = true;
		public boolean usePunch = true;
		public boolean useRelay = true;
		/** Preset for phone data / hotspot: relay-first, no probing, smaller host view distance. */
		public boolean cellularMode = false;
		/** Host-side data saver: 0 = leave as is, otherwise cap the world's view distance in chunks. */
		public int hostViewDistance = 0;

		public void applyCellular(boolean on) {
			cellularMode = on;
			upnp = !on;
			useDirect = !on;
			usePunch = !on;
			useRelay = true;
			hostViewDistance = on ? 6 : 0;
		}
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private final Path friendsFile = Identity.dir().resolve("friends.json");
	private final Path settingsFile = Identity.dir().resolve("settings.json");
	public final List<Friend> friends = new ArrayList<>();
	public Settings settings = new Settings();

	public FriendStore() {
		try {
			if (Files.exists(friendsFile)) {
				List<Friend> l = GSON.fromJson(Files.readString(friendsFile), new TypeToken<List<Friend>>() { }.getType());
				if (l != null) friends.addAll(l);
			}
			if (Files.exists(settingsFile)) {
				Settings s = GSON.fromJson(Files.readString(settingsFile), Settings.class);
				if (s != null) settings = s;
			}
		} catch (Exception e) {
			System.err.println("[PeerPlay] Could not read config: " + e);
		}
		for (Friend f : friends) {
			if (f.host == null) f.host = "";
			if (f.relay == null) f.relay = "";
		}
	}

	public synchronized void save() {
		try {
			Files.writeString(friendsFile, GSON.toJson(friends));
			Files.writeString(settingsFile, GSON.toJson(settings));
		} catch (Exception e) {
			System.err.println("[PeerPlay] Could not save config: " + e);
		}
	}

	public synchronized Friend byKey(String pubKey) {
		for (Friend f : friends) if (f.pubKey.equals(pubKey)) return f;
		return null;
	}

	/** Stable id the relay uses to route to a host: first 128 bits of SHA-256(pubkey). */
	public static String hostId(String pubKey) {
		try {
			byte[] h = MessageDigest.getInstance("SHA-256").digest(pubKey.getBytes(StandardCharsets.UTF_8));
			return HexFormat.of().formatHex(h, 0, 16);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/** pp2: + base64url(name \n host \n port \n pubkey \n relay). host and relay may be empty. */
	public static String makeCode(String name, String host, int port, String pubKey, String relay) {
		String raw = name + "\n" + host + "\n" + port + "\n" + pubKey + "\n" + relay;
		return "pp2:" + Base64.getUrlEncoder().withoutPadding().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
	}

	public static Friend parseCode(String code) {
		try {
			code = code.trim();
			boolean v2 = code.startsWith("pp2:");
			if (!v2 && !code.startsWith("pp1:")) return null;
			String raw = new String(Base64.getUrlDecoder().decode(code.substring(4)), StandardCharsets.UTF_8);
			String[] p = raw.split("\n", -1);
			if (p.length != (v2 ? 5 : 4)) return null;
			Friend f = new Friend();
			f.name = p[0];
			f.host = p[1];
			f.presencePort = Integer.parseInt(p[2]);
			f.pubKey = p[3];
			f.relay = v2 ? p[4] : "";
			if (f.pubKey.isBlank() || f.name.isBlank()) return null;
			if (f.host.isBlank() && f.relay.isBlank()) return null;
			return f;
		} catch (Exception e) {
			return null;
		}
	}

	public synchronized void add(Friend f) {
		friends.removeIf(x -> x.pubKey.equals(f.pubKey));
		friends.add(f);
		save();
	}

	public synchronized void remove(Friend f) {
		friends.remove(f);
		save();
	}
}
