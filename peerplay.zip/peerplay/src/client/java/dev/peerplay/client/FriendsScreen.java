package dev.peerplay.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;

import java.net.Socket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Widget-only friends list (no custom rendering, so it survives render API changes). */
public final class FriendsScreen extends Screen {
	private static final int PER_PAGE = 5;
	private final Screen parent;
	private final Map<String, PresenceService.Status> statuses = new ConcurrentHashMap<>();
	private int page;
	private boolean refreshed;
	private EditBox hostBox;
	private EditBox relayBox;
	private Component notice = Component.empty();

	public FriendsScreen(Screen parent) {
		super(Component.literal("PeerPlay Friends"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int cx = width / 2;
		int y = 10;
		addRenderableWidget(new StringWidget(cx - 150, y, 300, 12, title, font));
		y += 16;

		hostBox = new EditBox(font, cx - 150, y, 220, 18, Component.literal("My direct address"));
		hostBox.setMaxLength(128);
		hostBox.setHint(Component.literal("Direct address (optional)"));
		String host = PeerPlayClient.store.settings.publicHost;
		hostBox.setValue(host.isEmpty() && !PeerPlayClient.store.settings.cellularMode ? PeerPlayClient.detectedIp : host);
		addRenderableWidget(hostBox);
		addRenderableWidget(Button.builder(Component.literal("Copy my code"), b -> copyCode())
				.bounds(cx + 76, y - 1, 74, 20).build());
		y += 22;

		relayBox = new EditBox(font, cx - 150, y, 220, 18, Component.literal("Relay"));
		relayBox.setMaxLength(128);
		relayBox.setHint(Component.literal("Relay host:port (optional)"));
		relayBox.setValue(PeerPlayClient.store.settings.relay);
		addRenderableWidget(relayBox);
		addRenderableWidget(Button.builder(Component.literal("Apply relay"), b -> {
			saveSettings();
			PeerPlayClient.relayHost.reconfigure();
			notice = Component.literal("Relay saved.");
			rebuildWidgets();
		}).bounds(cx + 76, y - 1, 74, 20).build());
		y += 24;

		var friends = PeerPlayClient.store.friends;
		int start = page * PER_PAGE;
		for (int i = start; i < Math.min(friends.size(), start + PER_PAGE); i++) {
			FriendStore.Friend f = friends.get(i);
			PresenceService.Status st = statuses.get(f.pubKey);
			String label;
			if (st == null) label = "... " + f.name;
			else if (!st.reachable()) label = "○ " + f.name + " (" + st.error() + ")";
			else if (st.live()) label = "● " + f.name + " - hosting";
			else label = "○ " + f.name + " - online, not hosting";
			addRenderableWidget(new StringWidget(cx - 150, y + 5, 190, 12, Component.literal(label), font));
			Button join = Button.builder(Component.literal("Join"), b -> join(f))
					.bounds(cx + 44, y, 50, 20).build();
			join.active = st != null && st.reachable() && st.live();
			addRenderableWidget(join);
			addRenderableWidget(Button.builder(Component.literal("Remove"), b -> {
				PeerPlayClient.store.remove(f);
				rebuildWidgets();
			}).bounds(cx + 98, y, 52, 20).build());
			y += 24;
		}
		y = 10 + 16 + 22 + 24 + PER_PAGE * 24 + 2;

		addRenderableWidget(Button.builder(Component.literal("<"), b -> { page = Math.max(0, page - 1); rebuildWidgets(); })
				.bounds(cx - 150, y, 20, 20).build());
		addRenderableWidget(Button.builder(Component.literal(">"), b -> {
			if ((page + 1) * PER_PAGE < friends.size()) page++;
			rebuildWidgets();
		}).bounds(cx - 126, y, 20, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Add friend"), b -> {
			saveSettings();
			minecraft.setScreen(new AddFriendScreen(this));
		}).bounds(cx - 100, y, 80, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Refresh"), b -> refresh())
				.bounds(cx - 16, y, 60, 20).build());

		boolean inWorld = minecraft.getSingleplayerServer() != null;
		boolean live = PeerPlayClient.presence.isLive();
		Button bcast = Button.builder(Component.literal(live ? "Stop broadcasting" : "Broadcast world"), b -> {
			if (PeerPlayClient.presence.isLive()) {
				PeerPlayClient.stopBroadcast();
				notice = Component.literal("Stopped (world stays open until you quit it).");
			} else {
				int port = PeerPlayClient.startBroadcast(minecraft);
				notice = port > 0 ? Component.literal("Broadcasting. Friends join through PeerPlay.")
						: Component.literal("Could not open the world.");
			}
			rebuildWidgets();
		}).bounds(cx + 48, y, 102, 20).build();
		bcast.active = inWorld;
		addRenderableWidget(bcast);
		y += 24;

		addRenderableWidget(new StringWidget(cx - 150, y, 300, 12, notice, font));
		y += 14;
		addRenderableWidget(new StringWidget(cx - 150, y, 300, 12,
				Component.literal(PeerPlayClient.upnpStatus + " | " + PeerPlayClient.relayHost.state), font));
		addRenderableWidget(Button.builder(Component.literal("Network settings"), b -> {
			saveSettings();
			minecraft.setScreen(new SettingsScreen(this));
		}).bounds(cx - 150, height - 26, 146, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
				.bounds(cx + 4, height - 26, 146, 20).build());

		if (!refreshed) {
			refreshed = true;
			refresh();
		}
	}

	private void saveSettings() {
		PeerPlayClient.store.settings.publicHost = hostBox.getValue().trim();
		PeerPlayClient.store.settings.relay = relayBox.getValue().trim();
		PeerPlayClient.store.save();
	}

	private void copyCode() {
		saveSettings();
		var s = PeerPlayClient.store.settings;
		// With direct connections off (e.g. cellular mode) the code carries only the relay, so friends
		// never waste time dialing an address that cannot be reached.
		String direct = s.useDirect ? s.publicHost : "";
		String relay = s.useRelay ? s.relay : "";
		if (direct.isEmpty() && relay.isEmpty()) {
			notice = Component.literal("Set a relay (or a direct address and turn Direct on) first.");
			rebuildWidgets();
			return;
		}
		String code = FriendStore.makeCode(minecraft.getUser().getName(), direct, s.presencePort,
				PeerPlayClient.identity.publicKey(), relay);
		minecraft.keyboardHandler.setClipboard(code);
		notice = Component.literal("Friend code copied. Swap codes with your friend.");
		rebuildWidgets();
	}

	private void refresh() {
		for (FriendStore.Friend f : PeerPlayClient.store.friends) {
			Thread t = new Thread(() -> {
				PresenceService.Status st = PeerPlayClient.presence.query(f);
				statuses.put(f.pubKey, st);
				Minecraft.getInstance().execute(() -> {
					if (Minecraft.getInstance().screen == this) rebuildWidgets();
				});
			}, "PeerPlay-query");
			t.setDaemon(true);
			t.start();
		}
	}

	private void join(FriendStore.Friend f) {
		Minecraft mc = minecraft;
		notice = Component.literal("Connecting to " + f.name + "...");
		rebuildWidgets();
		Thread t = new Thread(() -> {
			try {
				Socket remote = GameLink.open(PeerPlayClient.transport, PeerPlayClient.identity, f);
				int port = GameLink.startLocalProxy(remote);
				mc.execute(() -> {
					String addr = "127.0.0.1:" + port;
					ServerData data = new ServerData(f.name + "'s world (" + PeerPlayClient.transport.lastRoute + ")",
							addr, ServerData.Type.OTHER);
					ConnectScreen.startConnecting(this, mc, ServerAddress.parseString(addr), data, false, null);
				});
			} catch (Exception e) {
				mc.execute(() -> {
					notice = Component.literal("Join failed: " + e.getMessage());
					rebuildWidgets();
				});
			}
		}, "PeerPlay-join");
		t.setDaemon(true);
		t.start();
	}

	@Override
	public void onClose() {
		saveSettings();
		minecraft.setScreen(parent);
	}
}
