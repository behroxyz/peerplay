package net.fabricmc.loader.api;
import java.nio.file.Path;
public class FabricLoader {
  public static Path dir;
  private static final FabricLoader I = new FabricLoader();
  public static FabricLoader getInstance() { return I; }
  public Path getConfigDir() { return dir; }
}
