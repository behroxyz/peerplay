import dev.peerplay.client.*;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.net.*;
import java.nio.file.*;

public class Test {
  static int pass, fail;
  static void check(String n, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + n); if (ok) pass++; else fail++; }

  static class Peer {
    Identity id; FriendStore store; Transport tr; PresenceService svc; RelayHost rh; String name; int port;
  }

  static Peer peer(String name, int port, String relay) throws Exception {
    FabricLoader.dir = Files.createTempDirectory(name);
    Peer p = new Peer(); p.name = name; p.port = port;
    p.id = Identity.loadOrCreate();
    p.store = new FriendStore();
    p.store.settings.presencePort = port;
    p.store.settings.relay = relay;
    p.tr = new Transport(p.store);
    p.svc = new PresenceService(p.id, p.store, p.tr);
    p.rh = new RelayHost(p.id, p.store, p.svc);
    p.svc.start();
    p.rh.reconfigure();
    return p;
  }
  static FriendStore.Friend friendOf(Peer p, String host, String relay) {
    return FriendStore.parseCode(FriendStore.makeCode(p.name, host, p.port, p.id.publicKey(), relay));
  }
  static void befriend(Peer a, Peer b, String bHost, String bRelay, String aHost, String aRelay) {
    a.store.add(friendOf(b, bHost, bRelay)); b.store.add(friendOf(a, aHost, aRelay));
  }
  static ServerSocket echo() throws Exception {
    ServerSocket ss = new ServerSocket(0, 5, InetAddress.getLoopbackAddress());
    Thread t = new Thread(() -> { try { while (true) { Socket s = ss.accept(); Thread h = new Thread(() -> { try { s.getInputStream().transferTo(s.getOutputStream()); } catch (Exception e) {} }); h.setDaemon(true); h.start(); } } catch (Exception e) {} });
    t.setDaemon(true); t.start(); return ss;
  }
  static boolean echoes(Socket s) throws Exception {
    s.setSoTimeout(5000);
    s.getOutputStream().write("hello-minecraft".getBytes()); s.getOutputStream().flush();
    byte[] b = new byte[15]; new DataInputStream(s.getInputStream()).readFully(b);
    return new String(b).equals("hello-minecraft");
  }
  static void waitRelay(Peer p) throws Exception { for (int i = 0; i < 50 && !p.rh.state.equals("relay: connected"); i++) Thread.sleep(100); }

  public static void main(String[] a) throws Exception {
    // ---------- pure helpers ----------
    byte[] req = new byte[20]; req[4]=0x21; req[5]=0x12; req[6]=(byte)0xA4; req[7]=0x42; for (int i=8;i<20;i++) req[i]=(byte)i;
    byte[] resp = new byte[32]; resp[1]=0x01; resp[0]=0x01; resp[1]=0x01; resp[2]=0; resp[3]=12; // type 0x0101, len 12
    System.arraycopy(req, 4, resp, 4, 16);
    resp[20]=0x00; resp[21]=0x20; resp[22]=0; resp[23]=8; resp[25]=0x01; resp[26]=0; resp[27]=0;
    byte[] ip = {(byte)203, 0, 113, 7}; for (int k=0;k<4;k++) resp[28+k] = (byte)(ip[k] ^ req[4+k]);
    check("STUN XOR-MAPPED-ADDRESS parsed", "203.0.113.7".equals(Stun.parse(resp, 32, req)));
    resp[10] ^= 1; check("STUN wrong transaction id rejected", Stun.parse(resp, 32, req) == null);
    check("private/CGNAT ranges detected", Stun.isPrivate("192.168.1.5") && Stun.isPrivate("100.72.1.1") && Stun.isPrivate("10.0.0.1") && !Stun.isPrivate("203.0.113.7"));
    check("UPnP LOCATION parsed", "http://192.168.1.1:5000/rootDesc.xml".equals(Upnp.parseLocation("HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=120\r\nLocation: http://192.168.1.1:5000/rootDesc.xml\r\nST: x\r\n\r\n")));
    String xml = "<root><device><serviceList><service><serviceType>urn:schemas-upnp-org:service:Layer3Forwarding:1</serviceType><controlURL>/l3f</controlURL></service></serviceList><deviceList><device><deviceList><device><serviceList>"
      + "<service><serviceType>urn:schemas-upnp-org:service:WANCommonInterfaceConfig:1</serviceType><controlURL>/cic</controlURL></service>"
      + "<service><serviceType>urn:schemas-upnp-org:service:WANIPConnection:1</serviceType><serviceId>x</serviceId><controlURL>/ctl/IPConn</controlURL></service>"
      + "</serviceList></device></deviceList></device></deviceList></device></root>";
    var svc = Upnp.pickService(Upnp.parseServices(xml));
    check("UPnP picks WANIPConnection control URL", svc != null && svc.controlUrl().equals("/ctl/IPConn") && svc.type().contains("WANIPConnection"));
    FriendStore.Friend v1 = FriendStore.parseCode("pp1:" + java.util.Base64.getUrlEncoder().withoutPadding().encodeToString("Old\n1.2.3.4\n25570\nKEY".getBytes()));
    check("old pp1 friend codes still accepted", v1 != null && v1.relay.isEmpty() && v1.host.equals("1.2.3.4"));
    check("code with neither address nor relay rejected", FriendStore.parseCode(FriendStore.makeCode("X", "", 25570, "K", "")) == null);

    // ---------- start relay ----------
    Thread rt = new Thread(() -> { try { RelayServer.main(new String[]{"25580"}); } catch (Exception e) { e.printStackTrace(); } });
    rt.setDaemon(true); rt.start(); Thread.sleep(500);
    String R = "127.0.0.1:25580";

    // ---------- direct route ----------
    Peer alice = peer("alice", 26001, ""), bob = peer("bob", 26002, "");
    befriend(alice, bob, "127.0.0.1", "", "127.0.0.1", "");
    FriendStore.Friend bobF = alice.store.friends.get(0);
    ServerSocket game = echo();
    bob.svc.setBroadcast(true, game.getLocalPort(), "Bob's world", "Bob");
    var st = alice.svc.query(bobF);
    check("direct: presence live", st.reachable() && st.live() && st.motd().equals("Bob's world"));
    Socket g = GameLink.open(alice.tr, alice.id, bobF);
    int lp = GameLink.startLocalProxy(g);
    try (Socket mc = new Socket("127.0.0.1", lp)) { check("direct: game bytes flow through gate + local proxy", echoes(mc) && alice.tr.lastRoute.equals("direct")); }

    // not a friend / not live / impersonation
    Peer eve = peer("eve", 26003, "");
    FriendStore.Friend bobForEve = friendOf(bob, "127.0.0.1", ""); eve.store.add(bobForEve);
    boolean refused = false; try { GameLink.open(eve.tr, eve.id, bobForEve).close(); } catch (IOException e) { refused = true; }
    check("stranger cannot join the game", refused);
    bob.svc.setBroadcast(false, 0, "", "Bob");
    refused = false; try { GameLink.open(alice.tr, alice.id, bobF).close(); } catch (IOException e) { refused = true; }
    check("friend refused while not hosting", refused);
    bob.svc.setBroadcast(true, game.getLocalPort(), "Bob's world", "Bob");
    FriendStore.Friend fakeBob = friendOf(eve, "127.0.0.1", ""); fakeBob.presencePort = 26003; fakeBob.name = "Bob";
    // Alice thinks Bob's key is Bob's but dials Eve's gate
    FriendStore.Friend bobAtEve = friendOf(bob, "127.0.0.1", ""); bobAtEve.presencePort = 26003;
    eve.store.add(friendOf(alice, "127.0.0.1", "")); eve.svc.setBroadcast(true, game.getLocalPort(), "evil", "Bob");
    refused = false; try { GameLink.open(alice.tr, alice.id, bobAtEve).close(); } catch (IOException e) { refused = e.getMessage().contains("identity mismatch"); }
    check("game join to an impostor gate is refused by the joiner", refused);

    // ---------- relay route ----------
    Peer carol = peer("carol", 26004, R), dave = peer("dave", 26005, R);
    waitRelay(carol); waitRelay(dave);
    check("hosts register with relay", carol.rh.state.equals("relay: connected") && dave.rh.state.equals("relay: connected"));
    befriend(carol, dave, "", R, "", R);   // no direct addresses at all
    FriendStore.Friend daveF = carol.store.friends.get(0);
    ServerSocket game2 = echo();
    dave.svc.setBroadcast(true, game2.getLocalPort(), "Dave's world", "Dave");
    st = carol.svc.query(daveF);
    check("relay-only: presence live over relay", st.reachable() && st.live() && st.motd().equals("Dave's world"));
    check("relay-only: route recorded as relay", carol.tr.lastRoute.equals("relay"));
    long t0 = System.currentTimeMillis();
    g = GameLink.open(carol.tr, carol.id, daveF);
    long took = System.currentTimeMillis() - t0;
    lp = GameLink.startLocalProxy(g);
    try (Socket mc = new Socket("127.0.0.1", lp)) { check("relay-only: game bytes flow (punch attempt then relay fallback, " + took + "ms, route=" + carol.tr.lastRoute + ")", echoes(mc)); }

    // direct address wrong -> falls back to relay
    FriendStore.Friend daveBadDirect = friendOf(dave, "127.0.0.1", R); daveBadDirect.presencePort = 1; // closed port
    st = carol.svc.query(daveBadDirect);
    check("dead direct address falls back to relay", st.reachable() && st.live() && carol.tr.lastRoute.equals("relay"));

    // relay path still enforces friendship
    Peer frank = peer("frank", 26006, R); waitRelay(frank);
    FriendStore.Friend daveForFrank = friendOf(dave, "", R); frank.store.add(daveForFrank);
    st = frank.svc.query(daveForFrank);
    check("relay: non-friend gets nothing", !st.reachable());
    refused = false; try { GameLink.open(frank.tr, frank.id, daveForFrank).close(); } catch (IOException e) { refused = true; }
    check("relay: non-friend cannot join game", refused);

    // multiple concurrent relayed sessions
    int okc = 0; Socket[] mcs = new Socket[3];
    for (int i = 0; i < 3; i++) { Socket gg = GameLink.open(carol.tr, carol.id, daveF); mcs[i] = new Socket("127.0.0.1", GameLink.startLocalProxy(gg)); }
    for (Socket s : mcs) { if (echoes(s)) okc++; s.close(); }
    check("3 concurrent sessions over the relay", okc == 3);

    // host leaves relay
    dave.rh.stop(); Thread.sleep(500);
    st = carol.svc.query(daveF);
    check("relay: departed host reported offline", !st.reachable());

    // ---------- cellular mode / route toggles ----------
    Peer gina = peer("gina", 26007, R), hal = peer("hal", 26008, R); waitRelay(gina); waitRelay(hal);
    // Both addresses are valid direct addresses; cellular mode must ignore them and use the relay.
    befriend(gina, hal, "127.0.0.1", R, "127.0.0.1", R);
    FriendStore.Friend halF = gina.store.friends.get(0);
    ServerSocket game3 = echo();
    hal.svc.setBroadcast(true, game3.getLocalPort(), "Hal", "Hal");
    gina.store.settings.applyCellular(true); hal.store.settings.applyCellular(true);
    check("cellular preset flips the route switches", !gina.store.settings.useDirect && !gina.store.settings.usePunch && !gina.store.settings.upnp && gina.store.settings.useRelay && gina.store.settings.hostViewDistance == 6);
    long t1 = System.currentTimeMillis();
    Socket gc = GameLink.open(gina.tr, gina.id, halF);
    long fast = System.currentTimeMillis() - t1;
    int lpc = GameLink.startLocalProxy(gc);
    try (Socket mc = new Socket("127.0.0.1", lpc)) { check("cellular: joins via relay, no punch delay (" + fast + "ms)", echoes(mc) && gina.tr.lastRoute.equals("relay") && fast < 1500); }
    st = gina.svc.query(halF);
    check("cellular: presence via relay", st.reachable() && st.live() && gina.tr.lastRoute.equals("relay"));

    gina.store.settings.applyCellular(false);
    gina.store.settings.useDirect = true;
    st = gina.svc.query(halF);
    check("direct re-enabled: uses direct route again", st.reachable() && gina.tr.lastRoute.equals("direct"));

    gina.store.settings.useDirect = false; gina.store.settings.useRelay = false;
    boolean noRoute = false; try { gina.tr.open(halF, true).close(); } catch (IOException e) { noRoute = e.getMessage().contains("Network settings"); }
    check("all routes off gives a clear error", noRoute);
    gina.store.settings.useRelay = true;

    gina.store.settings.usePunch = false;
    long t2 = System.currentTimeMillis();
    gina.store.settings.useDirect = false;
    gc = GameLink.open(gina.tr, gina.id, halF);
    check("punch off: route is relay", gina.tr.lastRoute.equals("relay") && System.currentTimeMillis() - t2 < 1500);
    gc.close();

    // relay host reconfigure: turning relay off then on re-registers
    hal.store.settings.useRelay = false; hal.rh.reconfigure(); Thread.sleep(300);
    gina.store.settings.useDirect = false; gina.store.settings.useRelay = true;
    st = gina.svc.query(halF);
    check("relay switched off on host: host unreachable", !st.reachable());
    hal.store.settings.useRelay = true; hal.rh.reconfigure(); waitRelay(hal);
    st = gina.svc.query(halF);
    check("relay switched back on: host reachable again", st.reachable() && st.live());

    // settings JSON from an older version still loads with new defaults
    FabricLoader.dir = Files.createTempDirectory("oldcfg");
    Files.writeString(Identity.dir().resolve("settings.json"), "{\"publicHost\":\"x.example\",\"presencePort\":25570,\"relay\":\"r:1\",\"upnp\":true}");
    FriendStore old = new FriendStore();
    check("older settings.json loads with defaults for new options", old.settings.useDirect && old.settings.usePunch && old.settings.useRelay && !old.settings.cellularMode && old.settings.publicHost.equals("x.example"));

    // persistence
    FabricLoader.dir = Files.createTempDirectory("persist");
    FriendStore p1 = new FriendStore(); p1.add(daveF); p1.settings.relay = R; p1.save();
    FriendStore p2 = new FriendStore();
    check("friends + relay setting persist", p2.friends.size() == 1 && p2.settings.relay.equals(R) && p2.friends.get(0).relay.equals(R));

    System.out.println("\n" + pass + " passed, " + fail + " failed");
    System.exit(fail == 0 ? 0 : 1);
  }
}
