#!/bin/sh
# Network/protocol tests (no Minecraft needed). Usage: tests/run.sh path/to/gson.jar   (JDK 25)
set -e
cd "$(dirname "$0")/.."
P=src/client/java/dev/peerplay/client
rm -rf /tmp/pp-test && mkdir /tmp/pp-test
javac -cp "$1" -d /tmp/pp-test tests/stub/net/fabricmc/loader/api/FabricLoader.java \
  $P/Identity.java $P/FriendStore.java $P/Pipe.java $P/Stun.java $P/Upnp.java $P/Transport.java \
  $P/PresenceService.java $P/GameLink.java $P/RelayHost.java relay/RelayServer.java tests/Test.java
java -cp "/tmp/pp-test:$1" Test
